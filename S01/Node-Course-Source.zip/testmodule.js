const output = require('./module.js');
console.log(output.greeting);